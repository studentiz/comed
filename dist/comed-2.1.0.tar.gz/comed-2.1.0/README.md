# CoMed: A Framework for Drug Co-Medication Risk Analysis

[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/release/python-3120/)
[![PyPI version](https://badge.fury.io/py/comed.svg?icon=si%3Apython)](https://badge.fury.io/py/comed)

## ⚠️ **IMPORTANT DISCLAIMER**

> **🚨 CRITICAL NOTICE: This tool is designed for research and educational purposes only.**
> 
> **CoMed is NOT intended for direct clinical use and should NOT be used as the sole basis for clinical decision-making.**
> 
> - ✅ **Intended Use**: Research, education, and clinical decision support for healthcare professionals
> - ❌ **NOT for**: Direct patient care, automated clinical decisions, or replacing professional medical judgment
> - 🔬 **Target Users**: Clinical researchers, healthcare professionals, and medical students
> - ⚖️ **Responsibility**: Always consult qualified healthcare professionals for clinical decisions
> 
> **By using this software, you acknowledge that it is for research and educational purposes only.**

## 🎯 Overview

CoMed is a comprehensive framework for analyzing drug co-medication risks using a modular architecture that supports RAG (Retrieval-Augmented Generation), CoT (Chain-of-Thought reasoning), and **True Multi-Agent systems**. Version 2.1.0 introduces genuine multi-agent collaboration with advanced communication, negotiation, and collective decision-making capabilities.

## 🔧 Key Features

### 1. Modular Architecture
- **RAG Module** (`rag.py`): Independent literature retrieval system
- **CoT Module** (`cot.py`): Chain-of-thought reasoning system  
- **Multi-Agent Module** (`agents.py`): True agent-to-agent collaboration

### 2. True Multi-Agent System (NEW in v2.1.0)
- **Advanced Agent Communication**: Real-time message passing with priority levels and message types
- **Multiple Collaboration Modes**: Sequential, Parallel, Consensus, Hierarchical, and Negotiation
- **Conflict Resolution**: Automated conflict detection and resolution mechanisms
- **Collective Decision Making**: Weighted consensus, expert-weighted, and confidence-weighted decisions
- **Agent Specialization**: Enhanced expertise levels and domain-specific knowledge
- **Negotiation Framework**: Multi-round negotiation with agreement checking
- **Collaboration Analytics**: Detailed interaction tracking and consensus measurement

## 📦 Installation

```bash
pip install comed
```

## 🚀 Quick Start

### Basic Usage

```python
import os
import comed

# Set required environment variables
os.environ["MODEL_NAME"] = "gpt-4o"
os.environ["API_BASE"] = "https://api.openai.com/v1"
os.environ["API_KEY"] = "your-api-key-here"

# Initialize system
drugs = ["warfarin", "aspirin", "ibuprofen"]
com = comed.CoMedData(drugs)

# Run full analysis
report_path = com.run_full_analysis(retmax=30, verbose=True)
print(f"Report generated at: {report_path}")
```

## 📚 Usage Examples

### Example 1: Step-by-Step Analysis

```python
import os
import comed

# Set API credentials
os.environ["MODEL_NAME"] = "gpt-4o"
os.environ["API_BASE"] = "https://api.openai.com/v1"
os.environ["API_KEY"] = "your-api-key-here"

# Create a CoMed instance
drugs = ["warfarin", "aspirin", "penicillin"]
com = comed.CoMedData(drugs)

# Search PubMed for literature
com.search(retmax=20, email="your.email@example.com")

# Analyze which papers mention drug combinations
com.analyze_associations()

# Evaluate risks across multiple dimensions
com.analyze_risks()

# Generate an HTML report
com.generate_report("Anticoagulant_Report.html")
```

### Example 2: Method Chaining

```python
import os
import comed

# Set API credentials
os.environ["MODEL_NAME"] = "gpt-4o"
os.environ["API_BASE"] = "https://api.openai.com/v1"
os.environ["API_KEY"] = "your-api-key-here"

# Create a CoMed instance and run analysis pipeline with method chaining
drugs = ["ibuprofen", "naproxen", "acetaminophen"]
com = comed.CoMedData(drugs)
com.search(retmax=30) \
   .analyze_associations() \
   .analyze_risks() \
   .generate_report("NSAID_Interactions.html")
```

### Example 3: Adding Drugs Incrementally

```python
import os
import comed

# Set API credentials
os.environ["MODEL_NAME"] = "gpt-4o"
os.environ["API_BASE"] = "https://api.openai.com/v1"
os.environ["API_KEY"] = "your-api-key-here"

# Start with a smaller set of drugs
com = comed.CoMedData(["warfarin", "aspirin"])
com.search(retmax=30)

# Add more drugs later
com.add_drugs(["heparin", "clopidogrel"])

# Only search for the new combinations
com.search(retmax=30)

# Complete the analysis pipeline
com.analyze_associations() \
   .analyze_risks() \
   .generate_report("Expanded_Drug_Report.html")
```


### Example 5: Enhanced Multi-Agent System (NEW in v2.1.0)

```python
from comed import MultiAgentSystem

# Initialize enhanced multi-agent system
agent_system = MultiAgentSystem(
    model_name="gpt-4o",
    api_key="your-key",
    api_base="https://api.openai.com/v1"
)

# Process drug combination with different collaboration modes
drug1, drug2 = "warfarin", "aspirin"
abstract = "Literature abstract content..."

# Consensus collaboration (default)
consensus_result = agent_system.process_drug_combination(
    drug1, drug2, abstract, 
    collaboration_mode="consensus"
)

# Negotiation collaboration
negotiation_result = agent_system.process_drug_combination(
    drug1, drug2, abstract, 
    collaboration_mode="negotiation"
)

# Hierarchical collaboration
hierarchical_result = agent_system.process_drug_combination(
    drug1, drug2, abstract, 
    collaboration_mode="hierarchical"
)

print("Enhanced Multi-Agent Analysis Results:")
print(f"Consensus Level: {consensus_result['consensus_level']}")
print(f"Agent Interactions: {consensus_result['agent_interactions']}")
print(f"Collaboration Summary: {consensus_result['collaboration_summary']}")

# Get detailed agent statistics
stats = agent_system.get_agent_stats()
print(f"Agent Statistics: {stats}")
```

### Example 6: Advanced Multi-Agent Collaboration

```python
# Test different collaboration modes
collaboration_modes = ["sequential", "parallel", "consensus", "hierarchical", "negotiation"]

for mode in collaboration_modes:
    print(f"\n=== Testing {mode.upper()} Collaboration ===")
    
    result = agent_system.process_drug_combination(
        "metformin", "lisinopril", abstract, 
        collaboration_mode=mode
    )
    
    print(f"Collaboration Mode: {mode}")
    print(f"Consensus Level: {result.get('consensus_level', 'N/A')}")
    print(f"Agent Interactions: {len(result.get('agent_interactions', {}))}")
    
    # Show agent conversation history
    for agent_name, agent in agent_system.agents.items():
        print(f"{agent.name} conversations: {len(agent.conversation_history)}")
```

## 🎮 Demo Examples

Run the comprehensive demo to see CoMed in action:

```bash
# Run basic demo
python examples/basic_demo.py

# Run quick start demo
python examples/quick_start.py
```

### Using Existing Data

If you already have association data (e.g., `ddc_papers_association_pd.csv`), you can skip the search and analysis steps:

```bash
# Load existing data and run multi-agent analysis
python examples/load_and_analyze.py

# Simple multi-agent test
python examples/simple_agent_test.py

# Direct multi-agent test
python examples/direct_agent_test.py
```

The demo includes:
- Basic usage examples
- Step-by-step analysis
- Method chaining
- Incremental drug addition
- Data persistence
- Multi-agent collaboration
- Direct multi-agent testing with existing data

## 🔧 Advanced Configuration

### Environment Variables

```bash
export MODEL_NAME="gpt-4o"
export API_BASE="https://api.openai.com/v1"
export API_KEY="your-api-key"
export LOG_DIR="logs"
```

### Custom Configuration

```python
# Configure LLM
com = comed.CoMedData(["warfarin", "aspirin"])
com.set_config({
    'model_name': 'gpt-4o',
    'api_base': 'https://api.openai.com/v1',
    'api_key': 'your-key'
})
```


## 🏗️ Architecture Design

### Enhanced Modular Design (v2.1.0)

```
CoMed v2.1.0 - True Multi-Agent System
├── RAG Module (rag.py)
│   ├── Literature retrieval
│   ├── Relevance filtering
│   └── Statistics
├── CoT Module (cot.py)
│   ├── Chain-of-thought reasoning
│   ├── Step-by-step analysis
│   └── Result formatting
├── Enhanced Multi-Agent Module (agents.py)
│   ├── Base Agent Class (Enhanced)
│   │   ├── Advanced communication protocols
│   │   ├── Message types and priorities
│   │   ├── Knowledge base management
│   │   └── Expertise level tracking
│   ├── Specialized Agents
│   │   ├── RiskAnalysisAgent (Enhanced)
│   │   ├── SafetyAgent (Enhanced)
│   │   └── ClinicalAgent (Enhanced)
│   ├── Collaboration Strategies
│   │   ├── Sequential collaboration
│   │   ├── Parallel collaboration
│   │   ├── Consensus building
│   │   ├── Hierarchical decision-making
│   │   └── Negotiation framework
│   ├── Conflict Resolution System
│   │   ├── Conflict detection
│   │   ├── Resolution strategies
│   │   └── Consensus building
│   └── Collective Decision Making
│       ├── Weighted consensus
│       ├── Expert-weighted decisions
│       └── Confidence-weighted decisions
└── Core Module (core.py)
    ├── Component integration
    ├── Configuration management
    └── Result aggregation
```

### Enhanced Data Flow (v2.1.0)

```
Drug Combinations → RAG Retrieval → CoT Reasoning → Enhanced Multi-Agent Collaboration → Result Integration → Report Generation
    ↓                 ↓              ↓                        ↓                              ↓
Literature Database  Association Analysis  Agent Communication & Negotiation  Collective Decision Making  Final Report
                                                      ↓
                                              ┌─────────────────┐
                                              │ Collaboration   │
                                              │ Modes:          │
                                              │ • Sequential    │
                                              │ • Parallel      │
                                              │ • Consensus     │
                                              │ • Hierarchical  │
                                              │ • Negotiation   │
                                              └─────────────────┘
```

## 📚 API Reference

### Core Classes

- `CoMedData`: Main analysis class
- `RAGSystem`: RAG retrieval system
- `CoTReasoner`: CoT reasoning system
- `MultiAgentSystem`: Enhanced multi-agent system with true collaboration
- `Agent`: Enhanced base agent class with communication capabilities
- `RiskAnalysisAgent`: Specialized risk analysis agent
- `SafetyAgent`: Specialized safety assessment agent
- `ClinicalAgent`: Specialized clinical decision agent
- `ConflictResolver`: Conflict resolution system
- `CollectiveDecisionMaker`: Collective decision making system

### Key Methods

#### Core Analysis Methods
- `run_full_analysis()`: Run complete analysis pipeline
- `set_config()`: Set configuration

#### Enhanced Multi-Agent Methods (NEW in v2.1.0)
- `process_drug_combination()`: Process with multiple collaboration modes
- `batch_process()`: Enhanced batch processing with collaboration modes
- `get_agent_stats()`: Get detailed agent statistics and interactions
- `send_message()`: Send messages between agents
- `receive_message()`: Receive and process agent messages
- `express_opinion()`: Express agent opinions for consensus building
- `_sequential_collaboration()`: Sequential agent collaboration
- `_parallel_collaboration()`: Parallel agent collaboration
- `_consensus_collaboration()`: Consensus-based collaboration
- `_hierarchical_collaboration()`: Hierarchical decision making
- `_negotiation_collaboration()`: Multi-round negotiation

### Environment Variables

- `MODEL_NAME`: Name of the LLM to use (e.g., "gpt-4o", "qwen2.5-32b-instruct")
- `API_BASE`: Base URL for the LLM API
- `API_KEY`: API key for LLM access
- `LOG_DIR`: Directory to store log files
- `OLD_OPENAI_API`: Whether to use the old OpenAI API format ("Yes" or "No")

## 🛠️ Development

### Adding New Components

```python
from comed.agents import Agent

class CustomAgent(Agent):
    def __init__(self, model_name, api_key, api_base):
        super().__init__("CustomAgent", "Custom Analysis", model_name, api_key, api_base)
    
    def _execute_task(self, input_data):
        # Implement custom analysis logic
        return {"custom_result": "Analysis result"}
```


## 🤝 Contributing

We welcome contributions in various forms:

1. **Code Contributions**: New features, bug fixes, performance optimizations
2. **Documentation Improvements**: Better examples, tutorials, API documentation
3. **Test Cases**: Unit tests, integration tests, benchmark tests
4. **Performance Optimization**: New evaluation metrics, test scenarios

## 📄 License

This project is licensed under the BSD License. See LICENSE file for details.

## 🚀 Version History

### v2.1.0 (Latest) - True Multi-Agent Collaboration
- **BREAKING CHANGES**: Enhanced multi-agent system with genuine collaboration
- **NEW FEATURES**:
  - Advanced agent-to-agent communication with message types and priorities
  - Multiple collaboration modes (Sequential, Parallel, Consensus, Hierarchical, Negotiation)
  - Conflict resolution system with multiple strategies
  - Collective decision making with weighted consensus
  - Enhanced agent specialization with expertise levels
  - Multi-round negotiation framework
  - Detailed collaboration analytics and interaction tracking
- **IMPROVEMENTS**:
  - Complete rewrite of agent communication protocols
  - Enhanced SafetyAgent and ClinicalAgent implementations
  - Advanced collaboration workflow management
  - Improved result integration with consensus measurement

### v2.0.1 - Modular Architecture
- Modular component separation
- Basic multi-agent framework

## 🙏 Acknowledgments

Thanks to the reviewers for their valuable feedback, which helped us build a more modular, evaluable framework. Special thanks for the feedback that led to the development of true multi-agent collaboration in v2.1.0.

## 📞 Contact

- Project Homepage: https://github.com/studentiz/comed
- Issue Reports: Please use GitHub Issues
- Email: studentiz@live.com

---

**Note**: This framework is for research purposes only and should not be used for clinical decision-making. Any medical decisions should be made in consultation with qualified healthcare professionals.