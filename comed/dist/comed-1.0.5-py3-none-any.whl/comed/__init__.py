"""
CoMed: A framework for analyzing co-medication risks using Chain-of-Thought reasoning.
"""

from .core import CoMedData
